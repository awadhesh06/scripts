#! /bin/bash

echo
"-------------------------------------------------"
echo "setting up alert manager"
kubectl create -f AlertmanagerConfigmap.yaml
echo
"-------------------------------------------------"
kubectl create -f AlerTemplateConfigMap.yaml
echo
"------------------------------------------------"
kubectl create -f Deployment.yaml
echo
"-------------------------------------------------"
kubectl create -f Service.yaml
echo
"------------------------------------------------"
echo "access Alert manager on port 31000"
echo 
"------------------------------------------------"
kubectl get pods -n monitoring
echo
"-------------------------------------------------"


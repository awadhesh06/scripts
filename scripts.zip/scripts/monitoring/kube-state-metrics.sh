#!/bin/bash

echo "-------------------------------------------------------------"
echo "setting up Kube State Metrics"
kubectl apply -f kube-state-metrics-configs/
echo "-------------------------------------------------------------"
kubectl get deployments kube-state-metrics -n kube-system
echo "-------------------------------------------------------------"

#!/bin/bash

echo "-------------------------------------------------------------"
echo "Setup Node Exporter on Kubernetes"
kubectl create -f daemonset.yaml
echo "-------------------------------------------------------------"
kubectl get daemonset -n monitoring
echo "-------------------------------------------------------------"
kubectl create -f service.yaml
echo "-------------------------------------------------------------"
kubectl get endpoints -n monitoring 
echo "-------------------------------------------------------------"

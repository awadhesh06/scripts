#!/bin/bash

echo "-------------------------------------------------------------"
echo "creating namespaces"
kubectl create ns consumerclf
kubectl create ns consumerai
kubectl create ns iat
kubectl create ns producerclf 
kubectl create ns quesconsumer
kubectl create ns cainaticsmongo 
kubectl creste ns reprocess

echo "-------------------------------------------------------------"
echo "creating secrtes for namespaces..!!"
kubectl create secret docker-registry acr-secret  --namespace consumerclf  --docker-server=cainaticscontainerregistry01.azurecr.io  --docker-username=cainaticscontainerregistry01  --docker-password=hHsCX6tVvo+c8U1Ek7I/zrLuN4iKiadZ  

kubectl create secret docker-registry acr-secret  --namespace consumerai  --docker-server=cainaticscontainerregistry01.azurecr.io  --docker-username=cainaticscontainerregistry01  --docker-password=hHsCX6tVvo+c8U1Ek7I/zrLuN4iKiadZ

kubectl create secret docker-registry acr-secret  --namespace iat  --docker-server=cainaticscontainerregistry01.azurecr.io  --docker-username=cainaticscontainerregistry01  --docker-password=hHsCX6tVvo+c8U1Ek7I/zrLuN4iKiadZ

kubectl create secret docker-registry acr-secret  --namespace producerclf  --docker-server=cainaticscontainerregistry01.azurecr.io  --docker-username=cainaticscontainerregistry01  --docker-password=hHsCX6tVvo+c8U1Ek7I/zrLuN4iKiadZ

kubectl create secret docker-registry acr-secret  --namespace quesconsumer  --docker-server=cainaticscontainerregistry01.azurecr.io  --docker-username=cainaticscontainerregistry01  --docker-password=hHsCX6tVvo+c8U1Ek7I/zrLuN4iKiadZ

kubectl create secret docker-registry acr-secret  --namespace reprocess  --docker-server=cainaticscontainerregistry01.azurecr.io  --docker-username=cainaticscontainerregistry01  --docker-password=hHsCX6tVvo+c8U1Ek7I/zrLuN4iKiadZ  

echo "-------------------------------------------------------------"
echo "Manually change the IP and build the jenkins job then apply the deployment with thier namsepaces..!"
echo "-------------------------------------------------------------"
* Local Deployment Automation Script *
------------------------------------------------------------

prerequisite:-
1)docker installed 
2)kubernetes installed 

--------------------------------------------------------------
before executing file give executable permission to each script using "chmod +x scriptname"

Steps to run scripts 
1)first run k8s_reset.sh script in reset folder

2)now setup kubernetes dashboard using kubernetesdashboard.sh     
script in dashboard folder

3)setup kafka and kowl using kafka.sh script in kafka folder 

4)run database.sh script for setting mysql and mongodb

5)run jenkins.sh script in jenkins dir to setup jenkins

6)setup monitoring (prometheus and grafana) usnig scripts in monitoring folder 

-------------------------------------------------------------

